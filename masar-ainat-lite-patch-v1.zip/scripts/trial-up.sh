#!/usr/bin/env bash
# تشغيل نسخة التجربة الخفيفة بلا خريطة OSRM.
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT="$(pwd)"
STAGING="$ROOT/deploy/staging"
ENV_FILE="$STAGING/.env.staging"
COMPOSE_FILE="$STAGING/docker-compose.trial.yml"

compose() {
  if docker compose version >/dev/null 2>&1; then
    docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" "$@"
  else
    docker-compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" "$@"
  fi
}

command -v docker >/dev/null 2>&1 || { echo "Docker غير مثبَّت."; exit 1; }
docker info >/dev/null 2>&1 || { echo "خدمة Docker لا تعمل."; exit 1; }

if [ ! -f "$ENV_FILE" ]; then
  python3 - "$STAGING/.env.staging.example" "$ENV_FILE" <<'PY'
import base64, os, re, secrets, string, sys
source, target = sys.argv[1], sys.argv[2]
alphabet = string.ascii_letters + string.digits + "!@#%^&*-_=+"
def password(n=28):
    return "".join(secrets.choice(alphabet) for _ in range(n))
lines = []
for line in open(source, encoding="utf-8").read().splitlines():
    match = re.match(r"^([A-Z_]+)=(.*)$", line)
    if match:
        key, value = match.group(1), match.group(2).strip()
        if value == "CHANGE_ME": value = password()
        elif value == "GENERATE_AT_DEPLOYMENT": value = base64.b64encode(os.urandom(48)).decode()
        elif value.endswith(":GENERATE_AT_DEPLOYMENT"):
            value = value.split(":", 1)[0] + ":" + base64.b64encode(os.urandom(32)).decode()
        line = f"{key}={value}"
    lines.append(line)
open(target, "w", encoding="utf-8").write("\n".join(lines) + "\n")
PY
  chmod 600 "$ENV_FILE"
fi

mkdir -p "$STAGING/certs"
if [ ! -f "$STAGING/certs/fullchain.pem" ] || [ ! -f "$STAGING/certs/privkey.pem" ]; then
  openssl req -x509 -newkey rsa:2048 -nodes -days 365 \
    -keyout "$STAGING/certs/privkey.pem" \
    -out "$STAGING/certs/fullchain.pem" \
    -subj "/CN=masar-staging.local" \
    -addext "subjectAltName=DNS:masar-staging.local,DNS:localhost,IP:127.0.0.1" \
    2>/dev/null
  chmod 600 "$STAGING/certs/privkey.pem"
fi

echo "تشغيل النسخة التجريبية الخفيفة — المسافات ستكون تقديرية."
compose up -d --build --wait --wait-timeout 300 db app nginx
compose exec -T app python3 -m masar_db.migrate up
SEED_PASSWORD="$(python3 -c 'import secrets,string; a=string.ascii_letters+string.digits+"!@#%^&*-_=+"; print("".join(secrets.choice(a) for _ in range(20)))')"
compose exec -T -e MASAR_SEED_PASSWORD="$SEED_PASSWORD" app python3 scripts/seed.py
compose exec -T app python3 scripts/make_trial_accounts.py
echo
echo "الواجهة: https://localhost:${MASAR_HTTPS_PORT:-443}"
echo "تنبيه: مزود الطرق الحالي haversine تقديري، وليس OSRM."
